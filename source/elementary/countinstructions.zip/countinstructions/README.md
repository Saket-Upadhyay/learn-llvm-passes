# Count Instructions
Counts the number of LLVM instructions.